﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfList
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> lst = null;
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new List<string> { "MH", "MP", "UP" };
        }

        private void l1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            update();
        }

        private void l2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (l2.SelectedValue.Equals("Pune") || l2.SelectedValue.Equals("Nagpur") || l2.SelectedValue.Equals("Mumbai"))
            {
                l1.ItemsSource = new List<string> { "MH" };
            }
            if (l2.SelectedValue.Equals("Bhopal") || l2.SelectedValue.Equals("Jabalpur") || l2.SelectedValue.Equals("Indor"))
            {
                l1.ItemsSource = new List<string> { "MP" };
            }
            if (l2.SelectedValue.Equals("Gorakhpur") || l2.SelectedValue.Equals("Lucknow") || l2.SelectedValue.Equals("Allahabad"))
            {
                l1.ItemsSource = new List<string> { "UP" };
            }
        }

        public List<string> update()
        {
            if(l1.SelectedIndex==0)
            {
                lst = new List<string> { "Pune", "Nagpur", "Mumbai" };
                l2.ItemsSource = lst;
            }
            if (l1.SelectedIndex == 1)
            {
                lst = new List<string> { "Bhopal", "Jabalpur", "Indor" };
                l2.ItemsSource = lst;
            }
            if (l1.SelectedIndex == 2)
            {
                lst = new List<string> { "Gorakhpur", "Lucknow", "Allahabad" };
                l2.ItemsSource = lst;
            }
            return lst;
        }
    }
}
